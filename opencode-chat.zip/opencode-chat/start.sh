#!/bin/sh
# OpenCode solo escucha en localhost; únicamente Next.js queda expuesto.
opencode serve --port 4096 --hostname 127.0.0.1 &
exec npx next start -p "${PORT:-3000}" -H 0.0.0.0
