# opencode-chat en Render

1. Sube esta carpeta a un repositorio de GitHub (el `.gitignore` ya excluye `.env`).
2. Render → New → Blueprint → elige el repo. Pega solo las claves de los proveedores que uses
   (ANTHROPIC_API_KEY, OPENAI_API_KEY, OPENROUTER_API_KEY); deja vacías las demás.
3. Cuando termine, abre la URL `.onrender.com`. El token de acceso está en Render →
   servicio → Environment → APP_ACCESS_TOKEN.

OpenCode corre dentro del mismo contenedor, solo en 127.0.0.1; no es accesible desde Internet.
