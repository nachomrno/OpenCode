import "server-only";
import { timingSafeEqual } from "node:crypto";

export function isAuthorized(req: Request): boolean {
  const expected = process.env.APP_ACCESS_TOKEN;
  if (!expected) return false; // sin token configurado, se deniega todo
  const given = (req.headers.get("authorization") ?? "").replace(/^Bearer /, "");
  const a = Buffer.from(given), b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
