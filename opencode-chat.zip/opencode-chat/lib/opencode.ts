import "server-only";

const BASE = process.env.OPENCODE_URL ?? "http://127.0.0.1:4096";

function authHeaders(): Record<string, string> {
  const pw = process.env.OPENCODE_SERVER_PASSWORD;
  if (!pw) return {};
  const user = process.env.OPENCODE_SERVER_USERNAME ?? "opencode";
  return { Authorization: "Basic " + Buffer.from(`${user}:${pw}`).toString("base64") };
}

export function oc(path: string, init: RequestInit = {}) {
  return fetch(BASE + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...authHeaders(), ...(init.headers ?? {}) },
    cache: "no-store",
  });
}

// GET /provider -> { all: Provider[], default, connected: string[] } (docs oficiales)
export async function listModels() {
  const res = await oc("/provider");
  if (!res.ok) throw new Error(`OpenCode respondió ${res.status}`);
  const data = await res.json();
  const connected = new Set<string>(data.connected ?? []);
  return (data.all as any[]).map((p) => ({
    id: p.id as string,
    name: (p.name ?? p.id) as string,
    connected: connected.has(p.id),
    models: Object.values(p.models ?? {}).map((m: any) => ({ id: m.id as string, name: (m.name ?? m.id) as string })),
  }));
}

export async function createSession(title?: string): Promise<string> {
  const res = await oc("/session", { method: "POST", body: JSON.stringify({ title }) });
  if (!res.ok) throw new Error(`No se pudo crear la sesión (${res.status})`);
  return (await res.json()).id;
}

export const abortSession = (id: string) => oc(`/session/${encodeURIComponent(id)}/abort`, { method: "POST" });
