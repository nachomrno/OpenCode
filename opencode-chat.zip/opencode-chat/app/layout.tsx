import "./globals.css";
export const metadata = { title: "OpenCode Chat" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="es"><body>{children}</body></html>);
}
