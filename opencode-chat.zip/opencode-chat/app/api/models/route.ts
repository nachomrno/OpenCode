import { isAuthorized } from "@/lib/auth";
import { listModels } from "@/lib/opencode";

export async function GET(req: Request) {
  if (!isAuthorized(req)) return Response.json({ error: "No autorizado" }, { status: 401 });
  try {
    return Response.json({ providers: await listModels() });
  } catch {
    return Response.json({ error: "No se pudo contactar con el servidor OpenCode" }, { status: 502 });
  }
}
