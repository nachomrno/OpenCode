import { z } from "zod";
import { isAuthorized } from "@/lib/auth";
import { oc, createSession, abortSession } from "@/lib/opencode";

const Body = z.object({
  sessionId: z.string().max(100).optional(),
  providerID: z.string().max(100),
  modelID: z.string().max(200),
  text: z.string().min(1).max(50_000),
});

// SSE: se abre /event, se lanza prompt_async y se reenvían los deltas de texto.
export async function POST(req: Request) {
  if (!isAuthorized(req)) return Response.json({ error: "No autorizado" }, { status: 401 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Entrada no válida" }, { status: 400 });
  const { providerID, modelID, text } = parsed.data;

  let sessionId = parsed.data.sessionId;
  try { sessionId ??= await createSession(); } catch (e: any) {
    return Response.json({ error: e.message }, { status: 502 });
  }

  const events = await oc("/event", { signal: req.signal, headers: { Accept: "text/event-stream" } });
  if (!events.ok || !events.body) return Response.json({ error: "Sin flujo de eventos de OpenCode" }, { status: 502 });

  const sent = await oc(`/session/${encodeURIComponent(sessionId)}/prompt_async`, {
    method: "POST",
    body: JSON.stringify({ model: { providerID, modelID }, parts: [{ type: "text", text }] }),
  });
  if (!sent.ok) return Response.json({ error: `OpenCode rechazó el mensaje (${sent.status})` }, { status: 502 });

  const enc = new TextEncoder(), dec = new TextDecoder();
  const sid = sessionId;
  const stream = new ReadableStream({
    async start(ctrl) {
      const out = (type: string, data: object) => ctrl.enqueue(enc.encode(`data: ${JSON.stringify({ type, ...data })}\n\n`));
      out("session", { sessionId: sid });
      req.signal.addEventListener("abort", () => { abortSession(sid).catch(() => {}); });
      const reader = events.body!.getReader();
      let buf = "";
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const chunks = buf.split("\n\n"); buf = chunks.pop() ?? "";
          for (const c of chunks) {
            const line = c.split("\n").find((l) => l.startsWith("data:"));
            if (!line) continue;
            let ev: any; try { ev = JSON.parse(line.slice(5)); } catch { continue; }
            const p = ev.properties ?? {};
            if (p.sessionID !== sid) continue;
            if (ev.type === "message.part.delta" && p.field === "text") out("delta", { text: p.delta });
            else if (ev.type === "session.error") { out("error", { message: "El proveedor devolvió un error (credenciales, límite o modelo no disponible)" }); return; }
            else if (ev.type === "session.idle") { out("done", {}); return; }
          }
        }
      } finally { ctrl.close(); reader.cancel().catch(() => {}); }
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-store" } });
}
