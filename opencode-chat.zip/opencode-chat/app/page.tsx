"use client";
import { useEffect, useRef, useState } from "react";

type Prov = { id: string; name: string; connected: boolean; models: { id: string; name: string }[] };
type Msg = { role: "user" | "assistant"; text: string };

function Rich({ text }: { text: string }) {
  return <>{text.split(/```/).map((p, i) => i % 2 ? <pre key={i}><code>{p.replace(/^\w*\n/, "")}</code></pre> : <span key={i}>{p}</span>)}</>;
}

export default function Page() {
  const [token, setToken] = useState("");
  const [authed, setAuthed] = useState(false);
  const [provs, setProvs] = useState<Prov[]>([]);
  const [sel, setSel] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const sid = useRef<string | undefined>(undefined);
  const ctl = useRef<AbortController | null>(null);
  const end = useRef<HTMLDivElement>(null);

  const H = (t = token) => ({ "Content-Type": "application/json", Authorization: `Bearer ${t}` });

  async function loadModels(t = token) {
    setErr("");
    const r = await fetch("/api/models", { headers: H(t) });
    const d = await r.json();
    if (!r.ok) { setErr(d.error ?? "Error"); setAuthed(false); return; }
    setProvs(d.providers); setAuthed(true); sessionStorage.setItem("tok", t);
    if (!sel) { const f = d.providers.find((p: Prov) => p.connected && p.models.length); if (f) setSel(`${f.id}|${f.models[0].id}`); }
  }
  useEffect(() => { const t = sessionStorage.getItem("tok"); if (t) { setToken(t); loadModels(t); } }, []);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  async function send() {
    if (!input.trim() || busy || !sel) return;
    const [providerID, modelID] = sel.split("|");
    const text = input; setInput(""); setErr(""); setBusy(true);
    setMsgs((m) => [...m, { role: "user", text }, { role: "assistant", text: "" }]);
    ctl.current = new AbortController();
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: H(), signal: ctl.current.signal,
        body: JSON.stringify({ sessionId: sid.current, providerID, modelID, text }) });
      if (!r.ok || !r.body) throw new Error((await r.json().catch(() => ({}))).error ?? "Error de red");
      const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "";
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n"); buf = parts.pop() ?? "";
        for (const p of parts) {
          if (!p.startsWith("data:")) continue;
          const ev = JSON.parse(p.slice(5));
          if (ev.type === "session") sid.current = ev.sessionId;
          else if (ev.type === "delta") setMsgs((m) => { const c = [...m]; c[c.length - 1] = { role: "assistant", text: c[c.length - 1].text + ev.text }; return c; });
          else if (ev.type === "error") setErr(ev.message);
        }
      }
    } catch (e: any) { if (e.name !== "AbortError") setErr(e.message); }
    finally { setBusy(false); }
  }

  if (!authed) return (
    <div className="c">
      <h2>OpenCode Chat</h2>
      <input type="password" placeholder="Token de acceso" value={token} onChange={(e) => setToken(e.target.value)} onKeyDown={(e) => e.key === "Enter" && loadModels()} />
      <button className="p" onClick={() => loadModels()}>Entrar</button>
      {err && <span style={{ color: "#dc2626" }}>{err}</span>}
    </div>
  );

  return (
    <div className="app">
      <header>
        <select value={sel} onChange={(e) => setSel(e.target.value)} aria-label="Modelo">
          {provs.map((p) => (
            <optgroup key={p.id} label={p.name + (p.connected ? "" : " (no configurado)")}>
              {p.models.map((m) => <option key={m.id} value={`${p.id}|${m.id}`} disabled={!p.connected}>{m.name} — {m.id}</option>)}
            </optgroup>
          ))}
        </select>
        <button onClick={() => loadModels()}>↻</button>
        <button onClick={() => { setMsgs([]); sid.current = undefined; }}>Nuevo</button>
      </header>
      <main>
        {msgs.length === 0 && <p style={{ color: "var(--mut)" }}>Elige un modelo y escribe tu mensaje.</p>}
        {msgs.map((m, i) => (
          <div key={i} className={`m ${m.role === "user" ? "u" : "a"}`}>
            <Rich text={m.text || (busy && i === msgs.length - 1 ? "…" : "")} />
            {m.role === "assistant" && m.text && <div><button onClick={() => navigator.clipboard.writeText(m.text)} style={{ marginTop: 6, padding: "2px 8px" }}>Copiar</button></div>}
          </div>
        ))}
        <div ref={end} />
      </main>
      {err && <div className="err">{err}</div>}
      <footer>
        <textarea rows={2} value={input} placeholder="Escribe… (Enter envía, Shift+Enter salto)" onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
        {busy ? <button onClick={() => ctl.current?.abort()}>Detener</button> : <button className="p" onClick={send} disabled={!sel}>Enviar</button>}
      </footer>
    </div>
  );
}
